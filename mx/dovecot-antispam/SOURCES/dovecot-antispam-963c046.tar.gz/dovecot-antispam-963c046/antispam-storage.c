#include "dovecot-version.h"

#include ANTISPAM_STORAGE
